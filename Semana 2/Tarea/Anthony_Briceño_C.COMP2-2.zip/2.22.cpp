// ¿Qué imprime este código?
#include <iostream>

int main() 
{
  std::cout << "*****\n****\n***\n**\n*\n " <<std::endl;
  return 0;
}