#include <iostream>

int main() {
  std::cout << "  CCC   +      +"   << std::endl;
  std::cout << " C      +      +"   << std::endl;
  std::cout << "C     +++++  +++++" << std::endl;
  std::cout << " C      +      +"   << std::endl;
  std::cout << "  CCC   +      +"   << std::endl;
  return 0;
}